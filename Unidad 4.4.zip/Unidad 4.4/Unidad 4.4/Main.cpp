//Bibliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//Variables//

Texture texture;
Texture texture1;

Sprite sprite;
Sprite sprite1;



//Entrada//

int main() {

	//Cargamos la textura del archivo//
	texture.loadFromFile("rcircleg.png");
	texture1.loadFromFile("cuad_yellow.png");


	//cargamos el material del sprite
    //verde
	sprite.setTexture(texture);
    //amarillo
	sprite1.setTexture(texture1);

    

	//escala de relaciones entre el cuadrado y el circulo

    float escalaX;
    float escalaY;
    float heightCuad;
    float widthCuad;
    float heightRef;
    float widthRef;


    heightCuad = (float)texture1.getSize().y;
    heightRef = (float)texture.getSize().y;
    widthCuad = (float)texture1.getSize().x;
    widthRef = (float)texture.getSize().x;
    escalaY = heightRef / heightCuad; escalaX = widthRef / widthCuad;

    


    sf::Vector2f position(350, 250);
    bool isDragging = false;
    float movimiento = 10.0f;

    
    sprite1.setScale(escalaX, escalaY);


	


	//creamos la ventana

	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana horrible");


	//loop principal
    while (App.isOpen())
    {
        sf::Event event;

        while (App.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                App.close();
            else if (event.type == sf::Event::KeyPressed)
            {
                if (Keyboard::isKeyPressed(Keyboard::Left) == true && position.x > 0)
                {
                    isDragging = true;
                    position.x -= movimiento;


                }
                else if (Keyboard::isKeyPressed(Keyboard::Right) == true && position.x + sprite.getGlobalBounds().width < App.getSize().x)
                {
                    isDragging = true;
                    position.x += movimiento;


                }
                else if (Keyboard::isKeyPressed(Keyboard::Down) == true && position.y + sprite.getGlobalBounds().height < App.getSize().y)
                {
                    isDragging = true;
                    position.y += movimiento;


                }
                else if (Keyboard::isKeyPressed(Keyboard::Up) == true && position.y > 0)
                {
                    isDragging = true;
                    position.y -= movimiento;


                }
                else if (Keyboard::isKeyPressed(Keyboard::Space) == true)
                {
                    sf::Vector2f originalScale(1.0f, 1.0f);
                    isDragging = true;
                    sprite1.setTexture(texture);
                    sprite1.setScale(originalScale);
                }

            }
        }

       
        sprite1.setPosition(position);

        
        App.clear();

        // Dibujar el sprite
        App.draw(sprite1);

        // Mostramos la ventana
        App.display();
    }

    return 0;
}

    
//en este ejercicio me habia trabado y me ayudo a resolverlo una compa (�ngeles)

