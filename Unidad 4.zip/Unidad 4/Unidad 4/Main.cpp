//Bibliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//Variables//

Texture mat_cursor;


Sprite cursor;






//Entrada//

int main() {

	sf::Event evt;

	//Cargamos la textura del cursor//
	mat_cursor.loadFromFile("rcircle.png");

    //cargamos el material del cursor
	cursor.setTexture(mat_cursor);
	cursor.setOrigin(mat_cursor.getSize().x / 2.0f, mat_cursor.getSize().y / 2.0f);
	
	cursor.setPosition(800/2, 600/2);
	
   //creamos la ventana

	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana horrible");
	//ocultar mouse
	App.setMouseCursorVisible(false);

	//loop principal
	while (App.isOpen())
	{
		Event evt;
		while (App.pollEvent(evt)) {
			//se procesan eventos//
			switch (evt.type)
			{
				//si se cierra la ventana//
			case sf::Event::Closed:
			App.close();
			break;

			case sf::Event::MouseMoved:

				cursor.setPosition(evt.mouseMove.x, evt.mouseMove.y);
				
				
			}

			

		}

		//limpiamos la ventana
		App.clear(sf::Color::White);

		//dibujamos la escena
		App.draw(cursor);
		




		//mostramos ventana
		App.display();

	}

	return 0;


}