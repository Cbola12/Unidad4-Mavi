//Bibliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;



int main() {

	//creamos la ventana

	sf::RenderWindow window(sf::VideoMode(800, 600, 32),
		"Que ventana horrible");


	//loop principal
	while (window.isOpen())
	{ 
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			if (event.type == sf::Event::Resized)
			{
				// Restringimos tama�o minimo y maximo de la ventana
				sf::Vector2u newSize = window.getSize();
				newSize.x = std::max(100u, std::min(newSize.x, 1000u));
				newSize.y = std::max(100u, std::min(newSize.y, 1000u));
				window.setSize(newSize);
			}
		}


		//limpiamos la ventana
		window.clear();


		//mostramos ventana
		window.display();

	}

	return 0;


}
