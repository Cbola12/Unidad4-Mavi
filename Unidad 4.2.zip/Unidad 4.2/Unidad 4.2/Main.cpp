//Bibliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//Variables//

Texture texture;


Sprite sprite;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;


//Entrada//

int main() {

	//Cargamos la textura del archivo//
	texture.loadFromFile("rcircle.png");

	//cargamos el material del sprite
	sprite.setTexture(texture);
	sprite2.setTexture(texture);
	sprite3.setTexture(texture);
	sprite4.setTexture(texture);

	//Movemos el Sprite

	sprite.setPosition(0, 480);
	sprite2.setPosition(0, 0);
	sprite3.setPosition(650, 0);
	sprite4.setPosition(650, 480);

	//creamos la ventana

	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana horrible");
	sf::Event evt;
	sf::Texture texture;
	sf::Vector2f offset;
	bool isDragging = false;
	sf::Sprite* draggedSprite = nullptr;



	//loop principal
	while (App.isOpen())
	{
        while (App.pollEvent(evt)) {
            if (evt.type == sf::Event::Closed)
                App.close();
            else if (evt.type == sf::Event::MouseButtonPressed) {
                if (evt.mouseButton.button == sf::Mouse::Left) {
                    if (sprite.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        offset = sprite.getPosition() - sf::Vector2f(evt.mouseButton.x, evt.mouseButton.y);
                        draggedSprite = &sprite;
                    }
                    else if (sprite2.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        offset = sprite2.getPosition() - sf::Vector2f(evt.mouseButton.x, evt.mouseButton.y);
                        draggedSprite = &sprite2;
                    }
                    else if (sprite3.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        offset = sprite3.getPosition() - sf::Vector2f(evt.mouseButton.x, evt.mouseButton.y);
                        draggedSprite = &sprite3;
                    }
                    else if (sprite4.getGlobalBounds().contains(evt.mouseButton.x, evt.mouseButton.y)) {
                        isDragging = true;
                        offset = sprite4.getPosition() - sf::Vector2f(evt.mouseButton.x, evt.mouseButton.y);
                        draggedSprite = &sprite4;
                    }
                }
            }
            else if (evt.type == sf::Event::MouseButtonReleased) {
                if (evt.mouseButton.button == sf::Mouse::Left) {
                    isDragging = false;
                    draggedSprite = nullptr;
                }
            }
        }

        if (isDragging && draggedSprite != nullptr) {
            sf::Vector2i mousePosition = sf::Mouse::getPosition(App);
            draggedSprite->setPosition(static_cast<sf::Vector2f>(mousePosition) + offset);
        }





		//limpiamos la ventana
		App.clear();

		//dibujamos la escena
		App.draw(sprite);
		App.draw(sprite2);
		App.draw(sprite3);
		App.draw(sprite4);





		//mostramos ventana
		App.display();

	}

	return 0;


}


//En este ejercicio me apoye en Chatgpt para resolver la parte de arrastrar los circulos.