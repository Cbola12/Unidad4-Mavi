//Bibliotecas
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

//variables

Texture texture_red;
Texture texture_blue;

Sprite red_circle;
Sprite blue_circle;


int main()
{

    

    //cargamos texturas
    texture_red.loadFromFile("rcircle.png");
    texture_blue.loadFromFile("rcircleb.png");

    //cargamos material
    red_circle.setTexture(texture_red);
    blue_circle.setTexture(texture_blue);
    red_circle.setOrigin(texture_red.getSize().x / 2.0f, texture_red.getSize().y / 2.0f);
    blue_circle.setOrigin(texture_blue.getSize().x / 2.0f, texture_blue.getSize().y / 2.0f);

    //creamos la ventana

    sf::RenderWindow App(sf::VideoMode(800, 600, 32),
        "Que ventana horrible");


    bool esVisible = false;
    bool esVisible1 = false;

    while (App.isOpen())
    {
        sf::Event event;

        while (App.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                App.close();
            else if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left)
            {
                int x = event.mouseButton.x;
                int y = event.mouseButton.y;
                red_circle.setPosition(x, y);
                esVisible = true;
            }
            else if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Right)
            {
                int x = event.mouseButton.x;
                int y = event.mouseButton.y;
                blue_circle.setPosition(x, y);
                esVisible1 = true;
            }
        }

        //App.clear(sf::Color::White); 
        //No limpiamos la ventana para poder incrementar la cantidad de circulos.


        if (esVisible) {
            App.draw(red_circle);

        }
        if (esVisible1) {
            App.draw(blue_circle);
        }

        


        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}

//En este ejercicio me apoye en el chatgpt porque no me daba cuenta como resolver algunas partes de los eventos.